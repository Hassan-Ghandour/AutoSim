#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "voiture.h"

int main() {
    Voiture voiture;
    initialiser_voiture(&voiture);
    srand(time(NULL));

    int choix;
    do {
        printf("\n=== AutoSim - Tableau de bord ===\n");
        printf("1. Demarrer moteur\n");
        printf("2. Accelerer\n");
        printf("3. Freiner\n");
        printf("4. Recharger la batterie\n");
        printf("5. Afficher l etat du vehicule\n");
        printf("6. Quitter\n");
        printf("Choix : ");
        scanf("%d", &choix);

        switch (choix) {
            case 1: demarrer_moteur(&voiture); break;
            case 2: accelerer(&voiture); break;
            case 3: freiner(&voiture); break;
            case 4: recharger(&voiture); break;
            case 5: afficher_etat(&voiture); break;
            case 6: printf("Fin de la simulation.\n"); break;
            default: printf("Choix invalide.\n");
        }

        verifier_alertes(&voiture);

    } while (choix != 6);

    return 0;
}
