#include <gtk/gtk.h>
#include "voiture.h"

Voiture voiture;

GtkWidget *label_vitesse, *label_temp, *label_batt, *label_km, *label_moteur, *label_alerte;
GtkWidget *bar_temp, *bar_batt;
GtkWidget *img;

void affichage() {
    char buf[64];
    sprintf(buf, "<span font='20' weight='bold'>%03d km/h</span>", voiture.vitesse);
    gtk_label_set_markup(GTK_LABEL(label_vitesse), buf);

    sprintf(buf, "%d °C", voiture.temperature);
    gtk_label_set_text(GTK_LABEL(label_temp), buf);

    sprintf(buf, "%d %%", voiture.batterie);
    gtk_label_set_text(GTK_LABEL(label_batt), buf);

    sprintf(buf, "%d km", voiture.kilometrage);
    gtk_label_set_text(GTK_LABEL(label_km), buf);

    gtk_label_set_text(GTK_LABEL(label_moteur), voiture.moteur_allume ? "Allumé" : "Éteint");

    gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(bar_temp), voiture.temperature / 120.0);
    gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(bar_batt), voiture.batterie / 100.0);
}

void afficher_alerte(const char *msg) {
    gtk_label_set_text(GTK_LABEL(label_alerte), msg);
}

void on_demarrer(GtkWidget *btn, gpointer data) {
    demarrer_moteur(&voiture);
    afficher_alerte("🚗 Moteur démarré");
    affichage();
}

void on_accelerer(GtkWidget *btn, gpointer data) {
    accelerer(&voiture);
    afficher_alerte("🚀 Accélération OK");
    affichage();
}

void on_freiner(GtkWidget *btn, gpointer data) {
    freiner(&voiture);
    afficher_alerte("🛑 Freinage effectué");
    affichage();
}

void on_recharger(GtkWidget *btn, gpointer data) {
    recharger(&voiture);
    afficher_alerte("🔋 Recharge complète");
    affichage();
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);
    initialiser_voiture(&voiture);

    GtkCssProvider *css = gtk_css_provider_new();
    gtk_css_provider_load_from_path(css, "style.css", NULL);
    gtk_style_context_add_provider_for_screen(gdk_screen_get_default(),
        GTK_STYLE_PROVIDER(css), GTK_STYLE_PROVIDER_PRIORITY_USER);

    GtkWidget *win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(win), "AutoSim Dashboard V3");
    gtk_window_set_default_size(GTK_WINDOW(win), 650, 500);
    g_signal_connect(win, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *main_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 15);
    gtk_container_add(GTK_CONTAINER(win), main_box);

    img = gtk_image_new_from_file("voiture.jpg");
    gtk_box_pack_start(GTK_BOX(main_box), img, FALSE, FALSE, 5);

    GtkWidget *titre = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(titre), "<span font='22' weight='bold'>🔧 AutoSim Dashboard</span>");
    gtk_box_pack_start(GTK_BOX(main_box), titre, FALSE, FALSE, 5);

    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 12);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 15);
    gtk_box_pack_start(GTK_BOX(main_box), grid, FALSE, FALSE, 10);

    label_moteur = gtk_label_new("Éteint");
    label_vitesse = gtk_label_new(NULL);
    label_temp = gtk_label_new(NULL);
    label_batt = gtk_label_new(NULL);
    label_km = gtk_label_new(NULL);
    bar_temp = gtk_progress_bar_new();
    bar_batt = gtk_progress_bar_new();

    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Moteur"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), label_moteur, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Vitesse"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), label_vitesse, 1, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Température"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), label_temp, 1, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), bar_temp, 2, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Batterie"), 0, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), label_batt, 1, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), bar_batt, 2, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Kilométrage"), 0, 4, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), label_km, 1, 4, 1, 1);

    GtkWidget *btnbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 15);
    gtk_box_pack_start(GTK_BOX(main_box), btnbox, FALSE, FALSE, 0);

    GtkWidget *b1 = gtk_button_new_with_label("🟢 Démarrer");
    GtkWidget *b2 = gtk_button_new_with_label("🚀 Accélérer");
    GtkWidget *b3 = gtk_button_new_with_label("🛑 Freiner");
    GtkWidget *b4 = gtk_button_new_with_label("🔋 Recharger");

    g_signal_connect(b1, "clicked", G_CALLBACK(on_demarrer), NULL);
    g_signal_connect(b2, "clicked", G_CALLBACK(on_accelerer), NULL);
    g_signal_connect(b3, "clicked", G_CALLBACK(on_freiner), NULL);
    g_signal_connect(b4, "clicked", G_CALLBACK(on_recharger), NULL);

    gtk_box_pack_start(GTK_BOX(btnbox), b1, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(btnbox), b2, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(btnbox), b3, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(btnbox), b4, TRUE, TRUE, 0);

    label_alerte = gtk_label_new("");
    gtk_box_pack_start(GTK_BOX(main_box), label_alerte, FALSE, FALSE, 5);

    gtk_widget_show_all(win);
    affichage();
    gtk_main();
    return 0;
}
