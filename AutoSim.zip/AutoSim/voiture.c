#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "voiture.h"



void enregistrer_alerte(const char* message) {
    FILE* f = fopen("logs.txt", "a");
    if (f) {
        time_t t = time(NULL);
        fprintf(f, "[%s] %s\n", strtok(ctime(&t), "\n"), message);
        fclose(f);
    }
}

void initialiser_voiture(Voiture* v) {
    v->moteur_allume = 0;
    v->vitesse = 0;
    v->batterie = 100;
    v->temperature = 25;
    v->kilometrage = 0;
    v->freinage_dur = 0;
    enregistrer_alerte("Systeme initialise.");
}

void afficher_etat(const Voiture* v) {
    printf("\n--- Etat du vehicule ---\n");
    printf("Moteur          : %s\n", v->moteur_allume ? "Allume" : "Eteint");
    printf("Vitesse         : %d km/h\n", v->vitesse);
    printf("Batterie        : %d %%\n", v->batterie);
    printf("Temperature     : %d °C\n", v->temperature);
    printf("Kilometrage     : %d km\n", v->kilometrage);
    sauvegarder_etat(v);
}

void demarrer_moteur(Voiture* v) {
    if (v->moteur_allume) {
        printf("Le moteur est deja allume.\n");
        return;
    }
    v->moteur_allume = 1;
    printf("Moteur demarre.\n");
    enregistrer_alerte("Moteur demarre.");
}

void accelerer(Voiture* v) {
    if (!v->moteur_allume) {
        printf("Moteur eteint. Demarrez d'abord.\n");
        return;
    }

    int ajout = rand() % 20 + 10; 
    v->vitesse += ajout;
    if (v->vitesse > 240) v->vitesse = 240; 

    v->batterie -= ajout / 4;
    if (v->batterie < 0) v->batterie = 0; 

    v->temperature += ajout / 5;
    if (v->temperature > 120) v->temperature = 120; 

    v->kilometrage += ajout / 2;

    printf("Acceleration de +%d km/h. Vitesse actuelle : %d km/h\n", ajout, v->vitesse);
    sauvegarder_etat(v);
}


void freiner(Voiture* v) {
    if (v->vitesse == 0) {
        printf("La voiture est deja arretee.\n");
        return;
    }

    int reduction = rand() % 30 + 10;
    if (reduction > v->vitesse) {
        v->freinage_dur = 1;
        enregistrer_alerte("Freinage brusque detecte !");
    }

    v->vitesse -= reduction;
    if (v->vitesse < 0) v->vitesse = 0;

    printf("Freinage de -%d km/h. Vitesse actuelle : %d km/h\n", reduction, v->vitesse);
    sauvegarder_etat(v);
}

void recharger(Voiture* v) {
    if (v->vitesse > 0) {
        printf("Impossible de recharger en roulant. Arretez-vous d'abord.\n");
        return;
    }
    v->batterie = 100;
    v->temperature -= 5;
    printf("Batterie rechargee a 100%%.\n");
    enregistrer_alerte("Recharge complete effectuee.");
    sauvegarder_etat(v);
}

void verifier_alertes(const Voiture* v) {
    if (v->batterie < 20) {
        printf("Batterie faible ! (%d%%)\n", v->batterie);
        enregistrer_alerte("Alerte : Batterie faible !");
    }
    if (v->temperature > 90) {
        printf("Temperature critique ! (%d°C)\n", v->temperature);
        enregistrer_alerte("Alerte : Température moteur elevee !");
    }
}

void sauvegarder_etat(const Voiture* v) {
    FILE* f = fopen("etat_voiture.txt", "a");
    if (f) {
        time_t t = time(NULL);
        fprintf(f, "\n[%s] État du véhicule :\n", strtok(ctime(&t), "\n"));
        fprintf(f, "Moteur     : %s\n", v->moteur_allume ? "Allume" : " Eteint");
        fprintf(f, "Vitesse    : %d km/h\n", v->vitesse);
        fprintf(f, "Batterie   : %d %%\n", v->batterie);
        fprintf(f, "Temperature: %d °C\n", v->temperature);
        fprintf(f, "Kilometrage: %d km\n", v->kilometrage);
        fclose(f);
    }
}
