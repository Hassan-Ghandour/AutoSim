#ifndef VOITURE_H
#define VOITURE_H

typedef struct {
    int moteur_allume;
    int vitesse;
    int batterie;
    int temperature;
    int kilometrage;
    int freinage_dur;
} Voiture;

void initialiser_voiture(Voiture* v);
void afficher_etat(const Voiture* v);
void demarrer_moteur(Voiture* v);
void accelerer(Voiture* v);
void freiner(Voiture* v);
void recharger(Voiture* v);
void verifier_alertes(const Voiture* v);
void enregistrer_alerte(const char* message);
void sauvegarder_etat(const Voiture* v);


#endif
